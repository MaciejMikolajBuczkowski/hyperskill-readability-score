import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DecimalFormat;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class Main {

    public static void main(String[] args) throws IOException {
        System.out.println("The text is:");
        String text = readFileAsString("file");
        System.out.println(text);

        // needed arrays
        String[] sentences = text.split("[!.?] ");
        String[] sentencesWithoutComas = text.replaceAll("[,|.|!|?]", "").split(" ");
        String[] words = String.join(" ", sentencesWithoutComas).split(" ");

        //needed parameters
        int sNumb = sentences.length;
        int wNumb = words.length;
        int cNumb = String.join("", text.split(" ")).length();
        int sylNumb = countSyllabesInText(words);
        int polNumb = countPollysyllabesInText(words);

        //output
        System.out.println("\nWords: " + wNumb);
        System.out.println("Sentences: " + sNumb);
        System.out.println("Characters: " + cNumb);
        System.out.println("Syllabes: " + sylNumb);
        System.out.println("Polysyllabes: " + polNumb);

        BigDecimal scoreARI = getARI(sNumb, wNumb, cNumb);
        BigDecimal scoreFK = getFleschKincaid(wNumb, sNumb, sylNumb);
        BigDecimal scoreSMOG = getSMOG(polNumb, sNumb);
        BigDecimal scoreCL = getCL(cNumb, wNumb, sNumb);

        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the score you want to calculate (ARI, FK, SMOG, CL, all): " );
        String input = scanner.nextLine();

        if (input.equals("ARI")) {
            printARI(scoreARI);
        } else if (input.equals("FK")) {
            printFK(scoreFK);
        } else if (input.equals("SMOG")) {
            printSMOG(scoreSMOG);
        } else if (input.equals("CL")) {
            printCL(scoreCL);
        } else if (input.equals("all")) {
            printARI(scoreARI);
            printFK(scoreFK);
            printSMOG(scoreSMOG);
            printCL(scoreCL);
        }

    }

    public static void printFK(BigDecimal scoreFK) {
        System.out.println("Flesch–Kincaid readability tests: " + scoreFK + " (" + printAge(scoreFK.doubleValue()) + ")");
    }

    public static void printARI(BigDecimal scoreARI) {
        System.out.println("Automated Readability Index: " + scoreARI + " (" + printAge(scoreARI.doubleValue()) + ")");
    }

    public static void printCL(BigDecimal scoreCL) {
        System.out.println("Coleman–Liau index: " + scoreCL + " (" + printAge(scoreCL.doubleValue()) + ")");
    }

    public static void printSMOG(BigDecimal scoreSMOG) {
        System.out.println("Simple Measure of Gobbledygook: " + scoreSMOG + " (" + printAge(scoreSMOG.doubleValue()) + ")");
    }


    public static String printAge(double score) {
        String result = "";
        int scoreRounded = (int) Math.ceil(score);

        switch (scoreRounded) {
            case 1:
                result = "about 6-years-old";
                break;
            case 2:
                result = "about 7-years-old";
                break;
            case 3:
                result = "about 8-years-old";
                break;
            case 4:
                result = "about 9-years-old";
                break;

            case 5:
                result = "about 10-years-old";
                break;
            case 6:
                result = "about 11-years-old";
                break;
            case 7:
                result = "about 12-years-old";
                break;
            case 8:
                result = "about 13-years-old";
                break;
            case 9:
                result = "about 14-years-old";
                break;
            case 10:
                result = "about 15-years-old";
                break;
            case 11:
                result = "about 16-years-old";
                break;
            case 12:
                result = "about 17-years-old";
                break;
            case 13:
                result = "about 18-years-old";
                break;
            default :
                result = "about 19-years-old";
                break;
        }

        return result;
    }

    public static BigDecimal roundUpToTwoDigitsAfterComa(double d) {
        return new BigDecimal(d).setScale(2, BigDecimal.ROUND_HALF_UP);
    }

    public static BigDecimal getCL(double cnumb, double words, double sentences) {
        double l = cnumb / words * 100;
        double s = sentences / words * 100;
        double result = 0.0588 * l - 0.296 * s - 15.8;

        return roundUpToTwoDigitsAfterComa(result);
    }

    public static BigDecimal getSMOG(double pollysyllabes, double sentences) {
        double result = 1.043 * Math.sqrt((pollysyllabes * 30.0 / sentences)) + 3.1291;

        return roundUpToTwoDigitsAfterComa(result);
    }

    public static BigDecimal getARI(double sNumb, double wNumb, double cNumb) {
        double score = (4.71 * cNumb / wNumb + 0.5 * wNumb / sNumb - 21.43);
        return roundUpToTwoDigitsAfterComa(score);
    }

    public static BigDecimal getFleschKincaid(int words, int sentences, int syllabes) {
        double result = 0.39 * (double) words / (double) sentences + 11.8 * (double) syllabes / (double) words - 15.59;
        return roundUpToTwoDigitsAfterComa(result);
    }

    public static String readFileAsString(String fileName) throws IOException {
        return new String(Files.readAllBytes(Paths.get(fileName)));
    }

    public static List<String> wordsLongerThanN(List<String> strings, int n) {
        return Optional.ofNullable(strings)
                .orElseGet(Collections::emptyList)
                .stream()
                .filter(Objects::nonNull)
                .filter(s -> s.length() > n)
                .toList();

    }

    public static int countPollysyllabesInText(String[] words) {
        int counter = 0;

        for (String s : words) {
            if (isPollysyllabe(s)) {
                counter++;
            }
        }

        return counter;
    }

    public static int countSyllabesInText(String[] words) {
        int counter = 0;
        List<Integer> syllabesInWords = new ArrayList<>();

        for (int i = 0; i < words.length; i++) {
            syllabesInWords.add(countVowelsInWord(words[i]));
        }

        for (Integer i : syllabesInWords) {
            counter += i;
        }

        return counter;
    }

    public static int countVowelsInWord(String str) {
        int counter = 0;
        String s = str.toLowerCase();

        for (int i = 0; i < s.length(); i++) {
            if (isVowel(s.charAt(i))) {
                if (i + 1 < s.length() && !isVowel(s.charAt(i + 1))) {
                    counter++;
                }
                if (i == s.length() - 1 && (s.charAt(s.length() - 1) != 'e')) {
                    counter++;
                }
            }

        }

        if (counter == 0) {
            counter = 1;
        }

        return counter;
    }


    public static boolean isVowel(char c) {
        char c1 = Character.toLowerCase(c);

        return c1 == 'a' || c1 == 'e' || c1 == 'i' || c1 == 'o' || c1 == 'u' || c1 == 'y';
    }

    public static boolean isPollysyllabe(String s) {
        return countVowelsInWord(s) > 2;
    }

}


